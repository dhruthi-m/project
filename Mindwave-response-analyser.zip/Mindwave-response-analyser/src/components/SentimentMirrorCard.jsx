import React from 'react';
import { Sparkles, Brain, AlertCircle, CheckCircle2, HelpCircle, ShieldCheck, HeartHandshake } from 'lucide-react';

export default function SentimentMirrorCard({ analysis, compact = false, showDisclaimer = true }) {
  if (!analysis) return null;

  const { sentiment, emotions = [], distortions = [], reframe } = analysis;

  const sentimentLabel = sentiment?.label || 'Neutral';
  const compoundScore = typeof sentiment?.compound === 'number' ? sentiment.compound.toFixed(2) : '0.00';
  const intensity = sentiment?.intensityPercent ?? 0;

  let badgeColor = '#64748B';
  let badgeBg = '#F1F5F9';
  if (sentimentLabel === 'Positive') {
    badgeColor = '#059669';
    badgeBg = '#ECFDF5';
  } else if (sentimentLabel === 'Negative') {
    badgeColor = '#DC2626';
    badgeBg = '#FEF2F2';
  }

  return (
    <div style={{
      marginTop: '1rem',
      padding: compact ? '1rem' : '1.25rem',
      borderRadius: '12px',
      background: 'linear-gradient(135deg, #FBFBFE 0%, #F5F3FF 100%)',
      border: '1px solid #E0E7FF',
      boxShadow: '0 4px 12px rgba(99, 102, 241, 0.05)'
    }}>
      {/* ── HEADER: SENTIMENT MIRROR BANNER ────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <div style={{
            width: '28px',
            height: '28px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #6366F1, #8B5CF6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff'
          }}>
            <Sparkles size={16} />
          </div>
          <div>
            <span style={{ fontSize: '0.95rem', fontWeight: 800, color: '#1E1B4B' }}>Multimodal Sentiment Mirror</span>
            <span style={{ fontSize: '0.75rem', color: '#6B7280', display: 'block' }}>NLP VADER & CBT Reflection Engine</span>
          </div>
        </div>

        {/* Sentiment Badge */}
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '0.4rem',
          padding: '0.35rem 0.75rem',
          borderRadius: '9999px',
          background: badgeBg,
          color: badgeColor,
          fontWeight: 700,
          fontSize: '0.84rem',
          border: `1px solid ${badgeColor}33`
        }}>
          <span>{sentimentLabel} Sentiment</span>
          <span style={{ fontSize: '0.75rem', opacity: 0.85 }}>(Score: {compoundScore})</span>
        </div>
      </div>

      {/* ── EMOTIONAL THEMES ROW ────────────────────────────────────────── */}
      <div style={{ marginBottom: '1rem' }}>
        <div style={{ fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', color: '#475569', marginBottom: '0.4rem' }}>
          Identified Emotional Themes
        </div>
        {emotions && emotions.length > 0 ? (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            {emotions.map((emo, idx) => {
              let emoBg = '#EEF2FF';
              let emoColor = '#4F46E5';
              if (emo.theme === 'Stress' || emo.theme === 'Anxiety') {
                emoBg = '#FEF3C7';
                emoColor = '#D97706';
              } else if (emo.theme === 'Sadness') {
                emoBg = '#E0F2FE';
                emoColor = '#0284C7';
              } else if (emo.theme === 'Frustration') {
                emoBg = '#FFE4E6';
                emoColor = '#E11D48';
              } else if (emo.theme === 'Happiness') {
                emoBg = '#DCFCE7';
                emoColor = '#16A34A';
              }

              return (
                <div key={idx} style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  padding: '0.25rem 0.6rem',
                  borderRadius: '6px',
                  background: emoBg,
                  color: emoColor,
                  fontSize: '0.8rem',
                  fontWeight: 600
                }}>
                  <span>{emo.theme}</span>
                  <span style={{ fontSize: '0.72rem', opacity: 0.8 }}>({emo.intensity})</span>
                  {emo.evidence && emo.evidence.length > 0 && (
                    <span style={{ fontSize: '0.7rem', opacity: 0.75 }}>— &quot;{emo.evidence.slice(0, 2).join(', ')}&quot;</span>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <p style={{ fontSize: '0.84rem', color: '#64748B', margin: 0, fontStyle: 'italic' }}>
            No dominant high-intensity emotional themes detected in this entry.
          </p>
        )}
      </div>

      {/* ── COGNITIVE DISTORTIONS (CBT THINKING PATTERNS) ──────────────── */}
      <div style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', color: '#475569', marginBottom: '0.4rem' }}>
          <Brain size={14} color="#6366F1" />
          <span>Cognitive Distortions (CBT Thinking Patterns)</span>
        </div>

        {distortions && distortions.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {distortions.map((dist, idx) => (
              <div key={idx} style={{
                padding: '0.65rem 0.85rem',
                borderRadius: '8px',
                background: '#FFFBEB',
                border: '1px solid #FDE68A',
                fontSize: '0.84rem',
                color: '#78350F'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700, marginBottom: '0.2rem' }}>
                  <AlertCircle size={14} color="#D97706" />
                  <span>{dist.pattern}</span>
                </div>
                <p style={{ margin: '0 0 0.35rem 0', color: '#92400E', fontSize: '0.82rem', lineHeight: '1.4' }}>
                  {dist.explanation}
                </p>
                {dist.evidence && (
                  <div style={{ fontSize: '0.78rem', color: '#B45309', background: '#FEF3C7', padding: '0.2rem 0.5rem', borderRadius: '4px', display: 'inline-block' }}>
                    <strong>Detected in text:</strong> &quot;{dist.evidence}&quot;
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            padding: '0.5rem 0.75rem',
            borderRadius: '8px',
            background: '#F0FDF4',
            border: '1px solid #BBF7D0',
            color: '#166534',
            fontSize: '0.84rem'
          }}>
            <CheckCircle2 size={16} color="#16A34A" />
            <span>No cognitive distortions detected. Your text reflects a balanced and grounded thought structure.</span>
          </div>
        )}
      </div>

      {/* ── COGNITIVE REFRAME (BALANCED ALTERNATIVE PERSPECTIVE) ────────── */}
      {reframe && (
        <div style={{
          padding: '0.85rem 1rem',
          borderRadius: '10px',
          background: '#EFF6FF',
          border: '1px solid #BFDBFE',
          marginBottom: '0.75rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#1D4ED8', fontWeight: 700, fontSize: '0.88rem', marginBottom: '0.4rem' }}>
            <HeartHandshake size={16} />
            <span>Cognitive Reframe: Balanced Alternative Perspective</span>
          </div>
          <p style={{ margin: '0 0 0.5rem 0', color: '#1E3A8A', fontSize: '0.86rem', lineHeight: '1.5' }}>
            {reframe.balanced_perspective}
          </p>

          {reframe.reflection_question && (
            <div style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: '0.4rem',
              padding: '0.5rem 0.75rem',
              borderRadius: '6px',
              background: '#DBEAFE',
              color: '#1E40AF',
              fontSize: '0.82rem',
              fontWeight: 600
            }}>
              <HelpCircle size={15} style={{ flexShrink: 0, marginTop: '2px' }} />
              <div>
                <span style={{ display: 'block', fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.04em', opacity: 0.85 }}>Reflection Prompt:</span>
                <span>{reframe.reflection_question}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── PRIVACY & CLINICAL DISCLAIMER ───────────────────────────────── */}
      {showDisclaimer && (
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.35rem',
          color: '#64748B',
          fontSize: '0.74rem',
          marginTop: '0.5rem',
          paddingTop: '0.5rem',
          borderTop: '1px dashed #E2E8F0'
        }}>
          <ShieldCheck size={13} style={{ flexShrink: 0 }} />
          <span>
            <strong>Reflective CBT Tool:</strong> AI-assisted thinking pattern estimation is private and non-diagnostic. It provides personal insight and does not replace professional psychiatric or clinical healthcare.
          </span>
        </div>
      )}
    </div>
  );
}

